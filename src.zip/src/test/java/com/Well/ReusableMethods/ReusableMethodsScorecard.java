package com.Well.ReusableMethods;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.Well.Engine.BaseClass;
import com.Well.Engine.CommonMethod;

public class ReusableMethodsScorecard extends BaseClass {

	public void Scorecardfill(int YesEnd, int NoStart, int NoEnd, int DifferencePlusOne)
			throws IOException, InterruptedException {
		List<WebElement> YesButton;
		List<WebElement> NoButton;

		NoButton = CommonMethod.findElements("V2ProjectPurseNo");
		int j = DifferencePlusOne;
		for (int i = NoStart; i <= NoEnd; i++) {
			int RemainingNo = NoButton.size();
			do {
				CommonMethod.click(NoButton.get(RemainingNo - j));
				Thread.sleep(1000);
				NoButton = CommonMethod.findElements("V2ProjectPurseNo");
			} while (NoButton.size() == RemainingNo);
			RemainingNo--;
			j--;
		}
		CommonMethod.WaitUntilVisibility("V2ProjectHsrScorecard", 300);
		CommonMethod.scrolldowntoElement("V2ProjectHsrScorecard");
		YesButton = CommonMethod.findElements("V2ProjectPurseYes");
		for (int i = 1; i <= YesEnd; i++) {
			int RemainingYes = YesButton.size();
			do {
				CommonMethod.WaitUntilVisibility("V2ProjectPurseYes", 300);
				CommonMethod.click("V2ProjectPurseYes");
				Thread.sleep(1000);
				YesButton = CommonMethod.findElements("V2ProjectPurseYes");
			} while (YesButton.size() == RemainingYes);
			RemainingYes--;
		}

	}
}