package com.Well.ReusableMethods;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.Well.Engine.BaseClass;
import com.Well.Engine.CommonMethod;

import io.opentelemetry.exporter.logging.SystemOutLogExporter;

public class ReusableMethodsHealthSafety extends BaseClass {
	
	public void RegisterHealthSafety(String SheetName,int rowNum) throws IOException, InterruptedException {

	   CommonMethod.click("ProjectNavBar");
	   CommonMethod.click("WELLHealthSafetyNavBar");
	   CommonMethod.click("HsrWellhealthstartprojectbtn");
	   CommonMethod.click("HsrEnrollnowbtn");
	   CommonMethod.click("HsrEnrollbtn");
	   CommonMethod.WaitUntilClickble("HsrenrollName", 30);
	   String erollName = "Automation hsr "+CommonMethod.randomNumber(8000000);
	   CommonMethod.sendKeys("HsrenrollName", erollName);
	   CommonMethod.ClickCheckbox("Hsrenrollcheckbox");
	   CommonMethod.click("OwnerOrgClick");
	   CommonMethod.sendKeys("OwnerOrg", "R");
	   CommonMethod.WaitUntilClickble("SelectOwnerOrg", 10);
	   CommonMethod.click("SelectOwnerOrg");
	   CommonMethod.selectdropdownrandom("HsrorgIndustry");
	   data.setCellData("Hsr", "OrgIndustry", 2, CommonMethod.getSelectedDropdownValue("OrgIndustry"));
	   CommonMethod.selectdropdown("Hsrenrollcountry",  data.getCellData(SheetName, "country", rowNum));
	   CommonMethod.selectdropdown("Hsrenrollstate", data.getCellData(SheetName, "state", rowNum));
       String ProjectAddress = USfaker.address().streetAddress();
	   String ProjectCity = USfaker.address().cityName();
	   String PostalCode = USfaker.address().zipCode();
	   CommonMethod.sendKeys("Hsrenrollstreet", ProjectAddress);
       CommonMethod.sendKeys("Hsrenrollcity", ProjectCity);
       CommonMethod.sendKeys("Hsrenrollpostalcode", PostalCode);
       CommonMethod.ClickCheckbox("Hsrbilladdcheckbox");
       CommonMethod.click("Hsrenrollcontinuebtn");
       CommonMethod.ClickCheckbox("Hsrregcheckbox");
       CommonMethod.selectdropdown("HsrIwbimemberdropdown","No");
       CommonMethod.click("HsrRegcontinuebtn");
       CommonMethod.click("HsrTypeoneEnrollbtn");
       CommonMethod.scrollUp();
       CommonMethod.sendKeys("Hsrlocations", "10");
       CommonMethod.click("HsrlocationsSpacetype");
       Thread.sleep(2000);
       CommonMethod.click("HsrlocationsSpaceOption");
       CommonMethod.clear("Hsrlocationsize");
       CommonMethod.sendKeys("Hsrlocationsize", "10");
	   CommonMethod.click("HsrLocContinuebutton");
	   CommonMethod.WaitUntilClickble("HsrYesMyOrganizationCbx", 30);
	   CommonMethod.ClickCheckbox("HsrYesMyOrganizationCbx");
	   CommonMethod.click("HsrLocContinuebutton");
	   CommonMethod.WaitUntilClickble("HsrProgramFeePublicrbtn", 60);
	   CommonMethod.ClickCheckbox("HsrProgramFeePublicrbtn");
	   CommonMethod.ClickCheckbox("HsrAcknowledecbx");
	   CommonMethod.click("HsrReviewbtn");
	   Thread.sleep(2000);  
	}
	public void StoreIdHealthSafety(String SheetName,int rowNum) throws IOException, InterruptedException {
		  Thread.sleep(10000); 
		CommonMethod.WaitUntilVisibility("StoreId", 300);
		String getId =CommonMethod.getText("StoreId"); 
      String[] stringArray = getId.split(": ");
      String getHsrId = stringArray[1].trim();
      data.setCellData("Hsr", "hsrId", 2, getHsrId);
	}
	
	public void SearchHealthSafetyByID (String SheetName,int rowNum) throws IOException, InterruptedException {
		CommonMethod.WaitUntilVisibility("ProjectNavBar", 300);
		CommonMethod.click("ProjectNavBar");
		 CommonMethod.WaitUntilVisibility("WELLHealthSafetyNavBar", 300);
		   CommonMethod.click("WELLHealthSafetyNavBar");
		   CommonMethod.WaitUntilVisibility("HsrIdSearch", 300);
		   CommonMethod.click("HsrIdSearch");
		   CommonMethod.sendKeys("HsrIdSearch", data.getCellData(SheetName, "hsrId", rowNum));
		   CommonMethod.click("HsrapplySearch");
		  Thread.sleep(3000);
		   CommonMethod.click("Hsrprojectidcompare");
	}
	
	public void CompleteScorecardHsrById(String SheetName, int rowNum) throws IOException, InterruptedException {
		Thread.sleep(3000);
		CommonMethod.WaitUntilVisibility("WellV2ScorecardTab", 300);
		CommonMethod.click("WellV2ScorecardTab");
		v2project.ScorecardfillHSRWPR(15,1,27,27); 
		
	}
	public void uploadDocumentInFeature(int LastFeatureNumber) throws IOException, InterruptedException {
		List<WebElement> Feature;
		Feature = CommonMethod.findElements("V2ProjectWPRPFeature"); 
		Feature = Feature.subList(0, LastFeatureNumber);
		CommonMethod.scrolldowntoElement("V2ProjectHsrScorecard");
		  for (WebElement f:Feature) {
			  CommonMethod.click(f);
			  CommonMethod.WaitUntilVisibility("V2ProjectWPRPDocIcon", 60);
				CommonMethod.click("V2ProjectWPRPDocIcon");
				CommonMethod.WaitUntilVisibility("HsrSelectTypeDoc", 60);
				CommonMethod.selectdropdownIndex("HsrSelectTypeDoc", 1);
				if(CommonMethod.isElementsExist("HsrLocationrtn",3)) {
					CommonMethod.ClickCheckbox("HsrLocationrtn");
				}
				if(CommonMethod.isElementsExist("HsrSelectLoc",3)) {
					CommonMethod.selectdropdownIndex("HsrSelectLoc", 1);
				}
				CommonMethod.WaitUntilVisibility("V2ProjectWPRVerificationMethod", 60);
				CommonMethod.selectdropdownIndex("V2ProjectWPRVerificationMethod", 1);
				CommonMethod.uploadFile("V2ProjectDocUpload", PortfolioLocationImportfile);
				Thread.sleep(2000);
				CommonMethod.Robustclick("HsrUploadDocFeature");
				CommonMethod.scrolldowntoElement("V2ProjectHsrScorecard");
                CommonMethod.click(f);
		  }
	}
	public void UploadHsrDocForFeature() throws IOException, InterruptedException {
		CommonMethod.WaitUntilVisibility("V2ProjectHsrScorecard", 300);
		uploadDocumentInFeature(15);	
}
	public void ReviewHsr(String SheetName, int rowNum) throws IOException, InterruptedException {
		Thread.sleep(3000);
		CommonMethod.WaitUntilVisibility("ReviwTab", 60);
		CommonMethod.click("ReviwTab");
		CommonMethod.WaitUntilVisibility("HsrSubmitReview", 60);
		CommonMethod.click("HsrSubmitReview");
		CommonMethod.WaitUntilClickble("HsrCommentReview", 60);
		CommonMethod.sendKeys("HsrCommentReview", "Preliminary Health-Safety Review");
		Thread.sleep(4000);
		CommonMethod.selectdropdown("HsrSelectedProjectPhaseReview", "Preliminary Health-Safety Review");
		CommonMethod.WaitUntilClickble("HsrSubmitDocReview", 60);
		CommonMethod.click("HsrSubmitDocReview");
		/*
		 * Admin Review
		 */
		CommonMethod.WaitUntilVisibility("AdminNavBar", 60);
		CommonMethod.click("AdminNavBar");
		CommonMethod.click("AdminWELLHealthsafetyNavBar");
		CommonMethod.WaitUntilVisibility("HsrAdminIdSearch", 60);
		CommonMethod.sendKeys("HsrAdminIdSearch", data.getCellData(SheetName, "hsrId", rowNum));
		CommonMethod.click("HsrApplybtn");
		Thread.sleep(2000);
		CommonMethod.click("AdminHsrIdClick");
		Thread.sleep(3000);
		CommonMethod.WaitUntilVisibility("ReviwTab", 60);
		CommonMethod.click("ReviwTab");
		CommonMethod.WaitUntilVisibility("HsrReviewViewbtn", 60);
		CommonMethod.click("HsrReviewViewbtn");
		CommonMethod.WaitUntilVisibility("V2ProjectReturnReviewbtn", 60);
		CommonMethod.click("V2ProjectReturnReviewbtn");
		CommonMethod.WaitUntilClickble("HsrReturnComment", 60);
		CommonMethod.sendKeys("HsrReturnComment", "Preliminary Precertification Review");
		CommonMethod.WaitUntilClickble("V2ProjectdocsubUpdatebtn", 60);
		Thread.sleep(1000);
		CommonMethod.click("V2ProjectdocsubUpdatebtn");
		CommonMethod.WaitUntilClickble("V2ProjectdocsubOkbtn", 60);
		CommonMethod.click("V2ProjectdocsubOkbtn");
		CommonMethod.scrollDown();
		Thread.sleep(1000);
		CommonMethod.WaitUntilClickble("V2ProjectPaymentstatus", 60);
		CommonMethod.ClickCheckbox("V2ProjectPaymentstatus");
		CommonMethod.WaitUntilClickble("V2ProjectReturnReviewSubmit", 60);
		CommonMethod.click("V2ProjectReturnReviewSubmit");
		Thread.sleep(2000);
		CommonMethod.WaitUntilClickble("V2ProjectReviwedStatus", 60);
		CommonMethod.assertcontainsmessage("V2ProjectReviwedStatus", "REVIEWED", "Verified Review status");
}
	public void UploadDocumentHsr() throws IOException, InterruptedException {
		Thread.sleep(2000);
		CommonMethod.WaitUntilVisibility("WellV2ProjectDocumentTab", 300);
		CommonMethod.click("WellV2ProjectDocumentTab");
		CommonMethod.WaitUntilVisibility("HsrAddDoc", 60);
		CommonMethod.click("HsrAddDoc");
		CommonMethod.WaitUntilVisibility("HsrSelectTypeDoc", 60);
		CommonMethod.selectdropdownIndex("HsrSelectTypeDoc", 1);
		CommonMethod.selectdropdownIndex("HsrType", 1);
		CommonMethod.uploadFile("V2ProjectDocUpload", PortfolioLocationImportfile);
		Thread.sleep(2000);
		CommonMethod.sendKeys("HsrReasonnarration", "Submitting Document");
		CommonMethod.Robustclick("HsrDocumentUploadbtn");
		CommonMethod.click("V2ProjectGeneralDoc");
		//CommonMethod.WaitUntilVisibility("V2ProjectGeneralDoc", 60);	
}
}
